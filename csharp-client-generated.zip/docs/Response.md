# IO.Swagger.Model.Response
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **bool?** |  | [optional] 
**Id** | **string** |  | [optional] 
**Message** | **Object** |  | [optional] 
**Meta** | **Object** |  | [optional] 
**Method** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

