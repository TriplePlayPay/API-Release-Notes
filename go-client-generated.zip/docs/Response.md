# Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **bool** |  | [optional] [default to null]
**Id** | **string** |  | [optional] [default to null]
**Message** | [***interface{}**](interface{}.md) |  | [optional] [default to null]
**Meta** | [***interface{}**](interface{}.md) |  | [optional] [default to null]
**Method** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

