# ApiApi

All URIs are relative to *https://www.tripleplaypay.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**authorize**](ApiApi.md#authorize) | **POST** /authorize | Used to verify funds when the total amount of the purchase is unknown.
[**callVoid**](ApiApi.md#callVoid) | **POST** /void | A Void transaction can be used to back out a previous Sale transaction.
[**charge**](ApiApi.md#charge) | **POST** /charge | Process payment or settle a previous charge. *card **bank ***terminal
[**client**](ApiApi.md#client) | **POST** /client | Get/Set configuration parameters
[**enroll**](ApiApi.md#enroll) | **POST** /enroll | Enroll a new child merchant or retrieve status of pending submission.
[**refund**](ApiApi.md#refund) | **POST** /refund | Credit/Refund transaction used to credit a cardholder for a previous transaction.
[**report**](ApiApi.md#report) | **GET** /report | Get transaction detail history
[**settle**](ApiApi.md#settle) | **POST** /settle | Same as sending a transactionId to charge, this method will settle an outstanding Authorization.
[**subscription**](ApiApi.md#subscription) | **POST** /subscription | Setup a payment subscription or get details/history. Can also send to /api/charge
[**terminal**](ApiApi.md#terminal) | **POST** /terminal | Configure new Credit Card Terminal or get status of existing.
[**tokenize**](ApiApi.md#tokenize) | **POST** /tokenize | Create a token for later use.

<a name="authorize"></a>
# **authorize**
> List&lt;Response&gt; authorize(amount, cc, mm, yy, cvv, zipZipcode, ticket, meta)

Used to verify funds when the total amount of the purchase is unknown.

Used to verify funds when the total amount of the purchase is unknown.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String amount = "amount_example"; // String | The total transaction amount. This is the amount of funds to move on the card
String cc = "cc_example"; // String | Credit Card Number with or without dashes
String mm = "mm_example"; // String | 2 digit Month
String yy = "yy_example"; // String | 2 digit Year
String cvv = "cvv_example"; // String | Card Verification Value found on the card (CVV2, CVC2, CID)
String zipZipcode = "zipZipcode_example"; // String | Postal code
String ticket = "ticket_example"; // String | Ticket Number used by POS
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.authorize(amount, cc, mm, yy, cvv, zipZipcode, ticket, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#authorize");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| The total transaction amount. This is the amount of funds to move on the card |
 **cc** | **String**| Credit Card Number with or without dashes |
 **mm** | **String**| 2 digit Month |
 **yy** | **String**| 2 digit Year |
 **cvv** | **String**| Card Verification Value found on the card (CVV2, CVC2, CID) |
 **zipZipcode** | **String**| Postal code | [optional]
 **ticket** | **String**| Ticket Number used by POS | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="callVoid"></a>
# **callVoid**
> List&lt;Response&gt; callVoid(id, ticket, meta)

A Void transaction can be used to back out a previous Sale transaction.

A Void transaction can be used to back out a previous Sale transaction.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String id = "id_example"; // String | Transaction ID of charged event
String ticket = "ticket_example"; // String | Ticket Number used by POS
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.callVoid(id, ticket, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#callVoid");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Transaction ID of charged event |
 **ticket** | **String**| Ticket Number used by POS | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="charge"></a>
# **charge**
> List&lt;Response&gt; charge(amount, terminal, cc, mm, yy, cvv, accountNumber, routingNumber, type, id, zipZipcode, ticket, items, meta)

Process payment or settle a previous charge. *card **bank ***terminal

Process payment or settle a previous charge. *card **bank ***terminal

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String amount = "amount_example"; // String | The total transaction amount. This is the amount of funds to move on the card
BigDecimal terminal = new BigDecimal(); // BigDecimal | Initiate a Credit Card Terminal transaction by its laneId or terminalId
String cc = "cc_example"; // String | Credit Card Number with or without dashes
String mm = "mm_example"; // String | 2 digit month
String yy = "yy_example"; // String | 2 digit year
String cvv = "cvv_example"; // String | Card Verification Value found on the card (CVV2, CVC2, CID)
String accountNumber = "accountNumber_example"; // String | Bank Account Number
String routingNumber = "routingNumber_example"; // String | Bank Routing Number
String type = "type_example"; // String | Options: checking, savings <code>default</code>: checking
String id = "id_example"; // String | Transaction ID used to settle an authorized payment method (cc or bank info then not required)
String zipZipcode = "zipZipcode_example"; // String | Postal code
String ticket = "ticket_example"; // String | Ticket Number used by POS
List<Items> items = Arrays.asList(new Items()); // List<Items> | List of items for receipt and level3 data. <code><br>[[id, price, description, tax, options],]<br>[{\"id\": \"\", \"price\": \"\", \"description\": \"\", \"tax\": \"\", \"options\": \"\"},]</code> 
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.charge(amount, terminal, cc, mm, yy, cvv, accountNumber, routingNumber, type, id, zipZipcode, ticket, items, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#charge");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| The total transaction amount. This is the amount of funds to move on the card |
 **terminal** | **BigDecimal**| Initiate a Credit Card Terminal transaction by its laneId or terminalId |
 **cc** | **String**| Credit Card Number with or without dashes |
 **mm** | **String**| 2 digit month |
 **yy** | **String**| 2 digit year |
 **cvv** | **String**| Card Verification Value found on the card (CVV2, CVC2, CID) |
 **accountNumber** | **String**| Bank Account Number |
 **routingNumber** | **String**| Bank Routing Number |
 **type** | **String**| Options: checking, savings &lt;code&gt;default&lt;/code&gt;: checking |
 **id** | **String**| Transaction ID used to settle an authorized payment method (cc or bank info then not required) | [optional]
 **zipZipcode** | **String**| Postal code | [optional]
 **ticket** | **String**| Ticket Number used by POS | [optional]
 **items** | [**List&lt;Items&gt;**](Items.md)| List of items for receipt and level3 data. &lt;code&gt;&lt;br&gt;[[id, price, description, tax, options],]&lt;br&gt;[{\&quot;id\&quot;: \&quot;\&quot;, \&quot;price\&quot;: \&quot;\&quot;, \&quot;description\&quot;: \&quot;\&quot;, \&quot;tax\&quot;: \&quot;\&quot;, \&quot;options\&quot;: \&quot;\&quot;},]&lt;/code&gt;  | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="client"></a>
# **client**
> List&lt;Response&gt; client(timezone, email, paramCallback, tax)

Get/Set configuration parameters

Get/Set configuration parameters

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String timezone = "timezone_example"; // String | Set your timezone
String email = "email_example"; // String | Set your notification email
String paramCallback = "paramCallback_example"; // String | Set your callback URL for notification of activity
String tax = "tax_example"; // String | Set your sales tax rate. (This helps simplify receipt generation and level3 detail)
try {
    List<Response> result = apiInstance.client(timezone, email, paramCallback, tax);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#client");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timezone** | **String**| Set your timezone | [optional]
 **email** | **String**| Set your notification email | [optional]
 **paramCallback** | **String**| Set your callback URL for notification of activity | [optional]
 **tax** | **String**| Set your sales tax rate. (This helps simplify receipt generation and level3 detail) | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="enroll"></a>
# **enroll**
> List&lt;Response&gt; enroll(dbaName, email, website, fedTxId, legalName, startDate, accountHolderName, accountType, accountNumber, routingNumber, ownershipType, businessDescription, businessPhoneNumber, businessAddress1, businessAddress2, businessCity, businessStateProvince, businessPostalCode, principleFirstName, principleLastName, principleSsn, principleDateOfBirth, principleAddressLine1, principleAddressLine2, principleCity, principleStateProvince, principlePostalCode, principleTitle, principleOwnershipPercentage, principlePhoneNumber, paramCallback, stockSymbol)

Enroll a new child merchant or retrieve status of pending submission.

Enroll a new child merchant or retrieve status of pending submission.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String dbaName = "dbaName_example"; // String | Doing Business As name. <code>*</code> Only field necessary for GET.
String email = "email_example"; // String | 
String website = "website_example"; // String | 
String fedTxId = "fedTxId_example"; // String | 
String legalName = "legalName_example"; // String | Legal Business Name
String startDate = "startDate_example"; // String | Business Start Date
String accountHolderName = "accountHolderName_example"; // String | 
String accountType = "accountType_example"; // String | 
String accountNumber = "accountNumber_example"; // String | Bank Account to deposit transactions. 
String routingNumber = "routingNumber_example"; // String | Bank Routing Number to deposit transactions.
String ownershipType = "ownershipType_example"; // String | [\"Sole Proprietor\", \"C-Corp Private\", \"C-Corp Public\", \"S-Corp Private\", \"S-Corp Public\", \"LLC Private\", \"LLC Public\", \"Not For Profit\", \"Partnership Private\", \"Partnership\", \"Government Agency\"]
String businessDescription = "businessDescription_example"; // String | 
String businessPhoneNumber = "businessPhoneNumber_example"; // String | 
String businessAddress1 = "businessAddress1_example"; // String | 
String businessAddress2 = "businessAddress2_example"; // String | 
String businessCity = "businessCity_example"; // String | 
String businessStateProvince = "businessStateProvince_example"; // String | 
String businessPostalCode = "businessPostalCode_example"; // String | 
String principleFirstName = "principleFirstName_example"; // String | Primary Owners First Name. Adding a number to the parameter allows for adding multiple principle owners. Example: <strong>2principle_first_name</strong>
String principleLastName = "principleLastName_example"; // String | Primary Owners Last Name.
String principleSsn = "principleSsn_example"; // String | Primary Owners Social Security Number
String principleDateOfBirth = "principleDateOfBirth_example"; // String | 
String principleAddressLine1 = "principleAddressLine1_example"; // String | 
String principleAddressLine2 = "principleAddressLine2_example"; // String | 
String principleCity = "principleCity_example"; // String | 
String principleStateProvince = "principleStateProvince_example"; // String | 
String principlePostalCode = "principlePostalCode_example"; // String | 
String principleTitle = "principleTitle_example"; // String | 
String principleOwnershipPercentage = "principleOwnershipPercentage_example"; // String | 
String principlePhoneNumber = "principlePhoneNumber_example"; // String | 
String paramCallback = "paramCallback_example"; // String | Optional URL we will forward changes to status to with enrollment payload.
String stockSymbol = "stockSymbol_example"; // String | 
try {
    List<Response> result = apiInstance.enroll(dbaName, email, website, fedTxId, legalName, startDate, accountHolderName, accountType, accountNumber, routingNumber, ownershipType, businessDescription, businessPhoneNumber, businessAddress1, businessAddress2, businessCity, businessStateProvince, businessPostalCode, principleFirstName, principleLastName, principleSsn, principleDateOfBirth, principleAddressLine1, principleAddressLine2, principleCity, principleStateProvince, principlePostalCode, principleTitle, principleOwnershipPercentage, principlePhoneNumber, paramCallback, stockSymbol);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#enroll");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dbaName** | **String**| Doing Business As name. &lt;code&gt;*&lt;/code&gt; Only field necessary for GET. |
 **email** | **String**|  |
 **website** | **String**|  |
 **fedTxId** | **String**|  |
 **legalName** | **String**| Legal Business Name |
 **startDate** | **String**| Business Start Date |
 **accountHolderName** | **String**|  |
 **accountType** | **String**|  |
 **accountNumber** | **String**| Bank Account to deposit transactions.  |
 **routingNumber** | **String**| Bank Routing Number to deposit transactions. |
 **ownershipType** | **String**| [\&quot;Sole Proprietor\&quot;, \&quot;C-Corp Private\&quot;, \&quot;C-Corp Public\&quot;, \&quot;S-Corp Private\&quot;, \&quot;S-Corp Public\&quot;, \&quot;LLC Private\&quot;, \&quot;LLC Public\&quot;, \&quot;Not For Profit\&quot;, \&quot;Partnership Private\&quot;, \&quot;Partnership\&quot;, \&quot;Government Agency\&quot;] |
 **businessDescription** | **String**|  |
 **businessPhoneNumber** | **String**|  |
 **businessAddress1** | **String**|  |
 **businessAddress2** | **String**|  |
 **businessCity** | **String**|  |
 **businessStateProvince** | **String**|  |
 **businessPostalCode** | **String**|  |
 **principleFirstName** | **String**| Primary Owners First Name. Adding a number to the parameter allows for adding multiple principle owners. Example: &lt;strong&gt;2principle_first_name&lt;/strong&gt; |
 **principleLastName** | **String**| Primary Owners Last Name. |
 **principleSsn** | **String**| Primary Owners Social Security Number |
 **principleDateOfBirth** | **String**|  |
 **principleAddressLine1** | **String**|  |
 **principleAddressLine2** | **String**|  |
 **principleCity** | **String**|  |
 **principleStateProvince** | **String**|  |
 **principlePostalCode** | **String**|  |
 **principleTitle** | **String**|  |
 **principleOwnershipPercentage** | **String**|  |
 **principlePhoneNumber** | **String**|  |
 **paramCallback** | **String**| Optional URL we will forward changes to status to with enrollment payload. | [optional]
 **stockSymbol** | **String**|  | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="refund"></a>
# **refund**
> List&lt;Response&gt; refund(amount, cc, mm, yy, cvv, zipZipcode, ticket, meta)

Credit/Refund transaction used to credit a cardholder for a previous transaction.

Credit/Refund transaction used to credit a cardholder for a previous transaction.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String amount = "amount_example"; // String | The total transaction amount. This is the amount of funds to move on the card
String cc = "cc_example"; // String | Credit Card Number with or without dashes
String mm = "mm_example"; // String | 2 digit month
String yy = "yy_example"; // String | 2 digit year
String cvv = "cvv_example"; // String | Card Verification Value found on the card (CVV2, CVC2, CID)
String zipZipcode = "zipZipcode_example"; // String | Postal code
String ticket = "ticket_example"; // String | Ticket Number used by POS
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.refund(amount, cc, mm, yy, cvv, zipZipcode, ticket, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#refund");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| The total transaction amount. This is the amount of funds to move on the card |
 **cc** | **String**| Credit Card Number with or without dashes |
 **mm** | **String**| 2 digit month |
 **yy** | **String**| 2 digit year |
 **cvv** | **String**| Card Verification Value found on the card (CVV2, CVC2, CID) |
 **zipZipcode** | **String**| Postal code | [optional]
 **ticket** | **String**| Ticket Number used by POS | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="report"></a>
# **report**
> List&lt;Response&gt; report(start, end, filter, timezone)

Get transaction detail history

Get transaction detail history

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String start = "start_example"; // String | Start of date range YYYY-MM-DD <code>*</code>defaults to that month
String end = "end_example"; // String | End of date range YYYY-MM-DD
Object filter = null; // Object | Filter results on any key value pair. <br>ex: <code>{\"method\":\"charge\"}</code> or nested <code>{\"message\":{\"details\": { \"Batch\": {\"HostItemID\": \"12\"}}}}</code>
String timezone = "timezone_example"; // String | Convert to timezone. <code>default</code>: tz set in client preferences
try {
    List<Response> result = apiInstance.report(start, end, filter, timezone);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#report");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start** | **String**| Start of date range YYYY-MM-DD &lt;code&gt;*&lt;/code&gt;defaults to that month | [optional]
 **end** | **String**| End of date range YYYY-MM-DD | [optional]
 **filter** | [**Object**](.md)| Filter results on any key value pair. &lt;br&gt;ex: &lt;code&gt;{\&quot;method\&quot;:\&quot;charge\&quot;}&lt;/code&gt; or nested &lt;code&gt;{\&quot;message\&quot;:{\&quot;details\&quot;: { \&quot;Batch\&quot;: {\&quot;HostItemID\&quot;: \&quot;12\&quot;}}}}&lt;/code&gt; | [optional]
 **timezone** | **String**| Convert to timezone. &lt;code&gt;default&lt;/code&gt;: tz set in client preferences | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="settle"></a>
# **settle**
> List&lt;Response&gt; settle(id, ticket, meta)

Same as sending a transactionId to charge, this method will settle an outstanding Authorization.

Same as sending a transactionId to charge, this method will settle an outstanding Authorization.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String id = "id_example"; // String | Transaction ID of charged event
String ticket = "ticket_example"; // String | Ticket Number used by POS
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.settle(id, ticket, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#settle");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Transaction ID of charged event |
 **ticket** | **String**| Ticket Number used by POS | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="subscription"></a>
# **subscription**
> List&lt;Response&gt; subscription(amount, start, interval, email, payment, id, cancelId, end, cycles, frequency)

Setup a payment subscription or get details/history. Can also send to /api/charge

Setup a payment subscription or get details/history. Can also send to /api/charge

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String amount = "amount_example"; // String | Amount charged per cycle.
String start = "start_example"; // String | Start of subscription <code>YYYY-MM-DD</code>
String interval = "interval_example"; // String | <code>daily, weekly, monthly, yearly</code>
String email = "email_example"; // String | Subscribers email address
Object payment = null; // Object | Same details as <code>charge</code>. (credit card only method supported currently)
String id = "id_example"; // String | GET specific subscription by id.  AN empty call gets a list of all current subscriptions
String cancelId = "cancelId_example"; // String | Subscription ID you want to cancel
String end = "end_example"; // String | End of subscription. <code>YYYY-MM-DD</code> Empty means forever.
String cycles = "cycles_example"; // String | Set number of iterations. <code>end</code> will be calculated for you. 
BigDecimal frequency = new BigDecimal(); // BigDecimal | 1 means every interval, 2 would mean every other interval <code>*</code> Every other week would be 2
try {
    List<Response> result = apiInstance.subscription(amount, start, interval, email, payment, id, cancelId, end, cycles, frequency);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#subscription");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| Amount charged per cycle. |
 **start** | **String**| Start of subscription &lt;code&gt;YYYY-MM-DD&lt;/code&gt; |
 **interval** | **String**| &lt;code&gt;daily, weekly, monthly, yearly&lt;/code&gt; |
 **email** | **String**| Subscribers email address |
 **payment** | [**Object**](.md)| Same details as &lt;code&gt;charge&lt;/code&gt;. (credit card only method supported currently) |
 **id** | **String**| GET specific subscription by id.  AN empty call gets a list of all current subscriptions | [optional]
 **cancelId** | **String**| Subscription ID you want to cancel | [optional]
 **end** | **String**| End of subscription. &lt;code&gt;YYYY-MM-DD&lt;/code&gt; Empty means forever. | [optional]
 **cycles** | **String**| Set number of iterations. &lt;code&gt;end&lt;/code&gt; will be calculated for you.  | [optional]
 **frequency** | **BigDecimal**| 1 means every interval, 2 would mean every other interval &lt;code&gt;*&lt;/code&gt; Every other week would be 2 | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="terminal"></a>
# **terminal**
> List&lt;Response&gt; terminal(terminalId, activationCode, meta)

Configure new Credit Card Terminal or get status of existing.

Configure new Credit Card Terminal or get status of existing.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String terminalId = "terminalId_example"; // String | Name of Terminal
String activationCode = "activationCode_example"; // String | Activation Code on Terminal Screen
Object meta = null; // Object | Optional user defined object to be returned with future response
try {
    List<Response> result = apiInstance.terminal(terminalId, activationCode, meta);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#terminal");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **terminalId** | **String**| Name of Terminal |
 **activationCode** | **String**| Activation Code on Terminal Screen | [optional]
 **meta** | [**Object**](.md)| Optional user defined object to be returned with future response | [optional]

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="tokenize"></a>
# **tokenize**
> List&lt;Response&gt; tokenize(cc, mm, yy, cvv, accountNumber, routingNumber)

Create a token for later use.

Create a token for later use.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ApiApi;


ApiApi apiInstance = new ApiApi();
String cc = "cc_example"; // String | Credit Card Number with or without dashes
String mm = "mm_example"; // String | 2 digit Month
String yy = "yy_example"; // String | 2 digit Year
String cvv = "cvv_example"; // String | Card Verification Value found on the card (CVV2, CVC2, CID)
String accountNumber = "accountNumber_example"; // String | Bank Account Number
String routingNumber = "routingNumber_example"; // String | Bank Routing Number
try {
    List<Response> result = apiInstance.tokenize(cc, mm, yy, cvv, accountNumber, routingNumber);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ApiApi#tokenize");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cc** | **String**| Credit Card Number with or without dashes |
 **mm** | **String**| 2 digit Month |
 **yy** | **String**| 2 digit Year |
 **cvv** | **String**| Card Verification Value found on the card (CVV2, CVC2, CID) |
 **accountNumber** | **String**| Bank Account Number |
 **routingNumber** | **String**| Bank Routing Number |

### Return type

[**List&lt;Response&gt;**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

