# Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **Boolean** |  |  [optional]
**id** | **String** |  |  [optional]
**message** | **Object** |  |  [optional]
**meta** | **Object** |  |  [optional]
**method** | **String** |  |  [optional]
