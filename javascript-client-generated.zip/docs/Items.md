# TriplePlayPayApi.Items

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
