# swagger_client.ApiApi

All URIs are relative to *https://www.tripleplaypay.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**authorize**](ApiApi.md#authorize) | **POST** /authorize | Used to verify funds when the total amount of the purchase is unknown.
[**charge**](ApiApi.md#charge) | **POST** /charge | Process payment or settle a previous charge. *card **bank ***terminal
[**client**](ApiApi.md#client) | **POST** /client | Get/Set configuration parameters
[**enroll**](ApiApi.md#enroll) | **POST** /enroll | Enroll a new child merchant or retrieve status of pending submission.
[**refund**](ApiApi.md#refund) | **POST** /refund | Credit/Refund transaction used to credit a cardholder for a previous transaction.
[**report**](ApiApi.md#report) | **GET** /report | Get transaction detail history
[**settle**](ApiApi.md#settle) | **POST** /settle | Same as sending a transactionId to charge, this method will settle an outstanding Authorization.
[**subscription**](ApiApi.md#subscription) | **POST** /subscription | Setup a payment subscription or get details/history. Can also send to /api/charge
[**terminal**](ApiApi.md#terminal) | **POST** /terminal | Configure new Credit Card Terminal or get status of existing.
[**tokenize**](ApiApi.md#tokenize) | **POST** /tokenize | Create a token for later use.
[**void**](ApiApi.md#void) | **POST** /void | A Void transaction can be used to back out a previous Sale transaction.

# **authorize**
> list[Response] authorize(amount, cc, mm, yy, cvv, zip__zipcode=zip__zipcode, ticket=ticket, meta=meta)

Used to verify funds when the total amount of the purchase is unknown.

Used to verify funds when the total amount of the purchase is unknown.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
amount = 'amount_example' # str | The total transaction amount. This is the amount of funds to move on the card
cc = 'cc_example' # str | Credit Card Number with or without dashes
mm = 'mm_example' # str | 2 digit Month
yy = 'yy_example' # str | 2 digit Year
cvv = 'cvv_example' # str | Card Verification Value found on the card (CVV2, CVC2, CID)
zip__zipcode = 'zip__zipcode_example' # str | Postal code (optional)
ticket = 'ticket_example' # str | Ticket Number used by POS (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # Used to verify funds when the total amount of the purchase is unknown.
    api_response = api_instance.authorize(amount, cc, mm, yy, cvv, zip__zipcode=zip__zipcode, ticket=ticket, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->authorize: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **str**| The total transaction amount. This is the amount of funds to move on the card | 
 **cc** | **str**| Credit Card Number with or without dashes | 
 **mm** | **str**| 2 digit Month | 
 **yy** | **str**| 2 digit Year | 
 **cvv** | **str**| Card Verification Value found on the card (CVV2, CVC2, CID) | 
 **zip__zipcode** | **str**| Postal code | [optional] 
 **ticket** | **str**| Ticket Number used by POS | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **charge**
> list[Response] charge(amount, terminal, cc, mm, yy, cvv, account_number, routing_number, type, id=id, zip__zipcode=zip__zipcode, ticket=ticket, items=items, meta=meta)

Process payment or settle a previous charge. *card **bank ***terminal

Process payment or settle a previous charge. *card **bank ***terminal

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
amount = 'amount_example' # str | The total transaction amount. This is the amount of funds to move on the card
terminal = 1.2 # float | Initiate a Credit Card Terminal transaction by its laneId or terminalId
cc = 'cc_example' # str | Credit Card Number with or without dashes
mm = 'mm_example' # str | 2 digit month
yy = 'yy_example' # str | 2 digit year
cvv = 'cvv_example' # str | Card Verification Value found on the card (CVV2, CVC2, CID)
account_number = 'account_number_example' # str | Bank Account Number
routing_number = 'routing_number_example' # str | Bank Routing Number
type = 'type_example' # str | Options: checking, savings <code>default</code>: checking
id = 'id_example' # str | Transaction ID used to settle an authorized payment method (cc or bank info then not required) (optional)
zip__zipcode = 'zip__zipcode_example' # str | Postal code (optional)
ticket = 'ticket_example' # str | Ticket Number used by POS (optional)
items = [swagger_client.Items()] # list[Items] | List of items for receipt and level3 data. <code><br>[[id, price, description, tax, options],]<br>[{\"id\": \"\", \"price\": \"\", \"description\": \"\", \"tax\": \"\", \"options\": \"\"},]</code>  (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # Process payment or settle a previous charge. *card **bank ***terminal
    api_response = api_instance.charge(amount, terminal, cc, mm, yy, cvv, account_number, routing_number, type, id=id, zip__zipcode=zip__zipcode, ticket=ticket, items=items, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->charge: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **str**| The total transaction amount. This is the amount of funds to move on the card | 
 **terminal** | **float**| Initiate a Credit Card Terminal transaction by its laneId or terminalId | 
 **cc** | **str**| Credit Card Number with or without dashes | 
 **mm** | **str**| 2 digit month | 
 **yy** | **str**| 2 digit year | 
 **cvv** | **str**| Card Verification Value found on the card (CVV2, CVC2, CID) | 
 **account_number** | **str**| Bank Account Number | 
 **routing_number** | **str**| Bank Routing Number | 
 **type** | **str**| Options: checking, savings &lt;code&gt;default&lt;/code&gt;: checking | 
 **id** | **str**| Transaction ID used to settle an authorized payment method (cc or bank info then not required) | [optional] 
 **zip__zipcode** | **str**| Postal code | [optional] 
 **ticket** | **str**| Ticket Number used by POS | [optional] 
 **items** | [**list[Items]**](Items.md)| List of items for receipt and level3 data. &lt;code&gt;&lt;br&gt;[[id, price, description, tax, options],]&lt;br&gt;[{\&quot;id\&quot;: \&quot;\&quot;, \&quot;price\&quot;: \&quot;\&quot;, \&quot;description\&quot;: \&quot;\&quot;, \&quot;tax\&quot;: \&quot;\&quot;, \&quot;options\&quot;: \&quot;\&quot;},]&lt;/code&gt;  | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **client**
> list[Response] client(timezone=timezone, email=email, param_callback=param_callback, tax=tax)

Get/Set configuration parameters

Get/Set configuration parameters

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
timezone = 'timezone_example' # str | Set your timezone (optional)
email = 'email_example' # str | Set your notification email (optional)
param_callback = 'param_callback_example' # str | Set your callback URL for notification of activity (optional)
tax = 'tax_example' # str | Set your sales tax rate. (This helps simplify receipt generation and level3 detail) (optional)

try:
    # Get/Set configuration parameters
    api_response = api_instance.client(timezone=timezone, email=email, param_callback=param_callback, tax=tax)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->client: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timezone** | **str**| Set your timezone | [optional] 
 **email** | **str**| Set your notification email | [optional] 
 **param_callback** | **str**| Set your callback URL for notification of activity | [optional] 
 **tax** | **str**| Set your sales tax rate. (This helps simplify receipt generation and level3 detail) | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **enroll**
> list[Response] enroll(dba_name, email, website, fed_tx_id, legal_name, start_date, account_holder_name, account_type, account_number, routing_number, ownership_type, business_description, business_phone_number, business_address_1, business_address_2, business_city, business_state_province, business_postal_code, principle_first_name, principle_last_name, principle_ssn, principle_date_of_birth, principle_address_line_1, principle_address_line_2, principle_city, principle_state_province, principle_postal_code, principle_title, principle_ownership_percentage, principle_phone_number, param_callback=param_callback, stock_symbol=stock_symbol)

Enroll a new child merchant or retrieve status of pending submission.

Enroll a new child merchant or retrieve status of pending submission.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
dba_name = 'dba_name_example' # str | Doing Business As name. <code>*</code> Only field necessary for GET.
email = 'email_example' # str | 
website = 'website_example' # str | 
fed_tx_id = 'fed_tx_id_example' # str | 
legal_name = 'legal_name_example' # str | Legal Business Name
start_date = 'start_date_example' # str | Business Start Date
account_holder_name = 'account_holder_name_example' # str | 
account_type = 'account_type_example' # str | 
account_number = 'account_number_example' # str | Bank Account to deposit transactions. 
routing_number = 'routing_number_example' # str | Bank Routing Number to deposit transactions.
ownership_type = 'ownership_type_example' # str | [\"Sole Proprietor\", \"C-Corp Private\", \"C-Corp Public\", \"S-Corp Private\", \"S-Corp Public\", \"LLC Private\", \"LLC Public\", \"Not For Profit\", \"Partnership Private\", \"Partnership\", \"Government Agency\"]
business_description = 'business_description_example' # str | 
business_phone_number = 'business_phone_number_example' # str | 
business_address_1 = 'business_address_1_example' # str | 
business_address_2 = 'business_address_2_example' # str | 
business_city = 'business_city_example' # str | 
business_state_province = 'business_state_province_example' # str | 
business_postal_code = 'business_postal_code_example' # str | 
principle_first_name = 'principle_first_name_example' # str | Primary Owners First Name. Adding a number to the parameter allows for adding multiple principle owners. Example: <strong>2principle_first_name</strong>
principle_last_name = 'principle_last_name_example' # str | Primary Owners Last Name.
principle_ssn = 'principle_ssn_example' # str | Primary Owners Social Security Number
principle_date_of_birth = 'principle_date_of_birth_example' # str | 
principle_address_line_1 = 'principle_address_line_1_example' # str | 
principle_address_line_2 = 'principle_address_line_2_example' # str | 
principle_city = 'principle_city_example' # str | 
principle_state_province = 'principle_state_province_example' # str | 
principle_postal_code = 'principle_postal_code_example' # str | 
principle_title = 'principle_title_example' # str | 
principle_ownership_percentage = 'principle_ownership_percentage_example' # str | 
principle_phone_number = 'principle_phone_number_example' # str | 
param_callback = 'param_callback_example' # str | Optional URL we will forward changes to status to with enrollment payload. (optional)
stock_symbol = 'stock_symbol_example' # str |  (optional)

try:
    # Enroll a new child merchant or retrieve status of pending submission.
    api_response = api_instance.enroll(dba_name, email, website, fed_tx_id, legal_name, start_date, account_holder_name, account_type, account_number, routing_number, ownership_type, business_description, business_phone_number, business_address_1, business_address_2, business_city, business_state_province, business_postal_code, principle_first_name, principle_last_name, principle_ssn, principle_date_of_birth, principle_address_line_1, principle_address_line_2, principle_city, principle_state_province, principle_postal_code, principle_title, principle_ownership_percentage, principle_phone_number, param_callback=param_callback, stock_symbol=stock_symbol)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->enroll: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dba_name** | **str**| Doing Business As name. &lt;code&gt;*&lt;/code&gt; Only field necessary for GET. | 
 **email** | **str**|  | 
 **website** | **str**|  | 
 **fed_tx_id** | **str**|  | 
 **legal_name** | **str**| Legal Business Name | 
 **start_date** | **str**| Business Start Date | 
 **account_holder_name** | **str**|  | 
 **account_type** | **str**|  | 
 **account_number** | **str**| Bank Account to deposit transactions.  | 
 **routing_number** | **str**| Bank Routing Number to deposit transactions. | 
 **ownership_type** | **str**| [\&quot;Sole Proprietor\&quot;, \&quot;C-Corp Private\&quot;, \&quot;C-Corp Public\&quot;, \&quot;S-Corp Private\&quot;, \&quot;S-Corp Public\&quot;, \&quot;LLC Private\&quot;, \&quot;LLC Public\&quot;, \&quot;Not For Profit\&quot;, \&quot;Partnership Private\&quot;, \&quot;Partnership\&quot;, \&quot;Government Agency\&quot;] | 
 **business_description** | **str**|  | 
 **business_phone_number** | **str**|  | 
 **business_address_1** | **str**|  | 
 **business_address_2** | **str**|  | 
 **business_city** | **str**|  | 
 **business_state_province** | **str**|  | 
 **business_postal_code** | **str**|  | 
 **principle_first_name** | **str**| Primary Owners First Name. Adding a number to the parameter allows for adding multiple principle owners. Example: &lt;strong&gt;2principle_first_name&lt;/strong&gt; | 
 **principle_last_name** | **str**| Primary Owners Last Name. | 
 **principle_ssn** | **str**| Primary Owners Social Security Number | 
 **principle_date_of_birth** | **str**|  | 
 **principle_address_line_1** | **str**|  | 
 **principle_address_line_2** | **str**|  | 
 **principle_city** | **str**|  | 
 **principle_state_province** | **str**|  | 
 **principle_postal_code** | **str**|  | 
 **principle_title** | **str**|  | 
 **principle_ownership_percentage** | **str**|  | 
 **principle_phone_number** | **str**|  | 
 **param_callback** | **str**| Optional URL we will forward changes to status to with enrollment payload. | [optional] 
 **stock_symbol** | **str**|  | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **refund**
> list[Response] refund(amount, cc, mm, yy, cvv, zip__zipcode=zip__zipcode, ticket=ticket, meta=meta)

Credit/Refund transaction used to credit a cardholder for a previous transaction.

Credit/Refund transaction used to credit a cardholder for a previous transaction.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
amount = 'amount_example' # str | The total transaction amount. This is the amount of funds to move on the card
cc = 'cc_example' # str | Credit Card Number with or without dashes
mm = 'mm_example' # str | 2 digit month
yy = 'yy_example' # str | 2 digit year
cvv = 'cvv_example' # str | Card Verification Value found on the card (CVV2, CVC2, CID)
zip__zipcode = 'zip__zipcode_example' # str | Postal code (optional)
ticket = 'ticket_example' # str | Ticket Number used by POS (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # Credit/Refund transaction used to credit a cardholder for a previous transaction.
    api_response = api_instance.refund(amount, cc, mm, yy, cvv, zip__zipcode=zip__zipcode, ticket=ticket, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->refund: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **str**| The total transaction amount. This is the amount of funds to move on the card | 
 **cc** | **str**| Credit Card Number with or without dashes | 
 **mm** | **str**| 2 digit month | 
 **yy** | **str**| 2 digit year | 
 **cvv** | **str**| Card Verification Value found on the card (CVV2, CVC2, CID) | 
 **zip__zipcode** | **str**| Postal code | [optional] 
 **ticket** | **str**| Ticket Number used by POS | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **report**
> list[Response] report(start=start, end=end, filter=filter, timezone=timezone)

Get transaction detail history

Get transaction detail history

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
start = 'start_example' # str | Start of date range YYYY-MM-DD <code>*</code>defaults to that month (optional)
end = 'end_example' # str | End of date range YYYY-MM-DD (optional)
filter = NULL # object | Filter results on any key value pair. <br>ex: <code>{\"method\":\"charge\"}</code> or nested <code>{\"message\":{\"details\": { \"Batch\": {\"HostItemID\": \"12\"}}}}</code> (optional)
timezone = 'timezone_example' # str | Convert to timezone. <code>default</code>: tz set in client preferences (optional)

try:
    # Get transaction detail history
    api_response = api_instance.report(start=start, end=end, filter=filter, timezone=timezone)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->report: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start** | **str**| Start of date range YYYY-MM-DD &lt;code&gt;*&lt;/code&gt;defaults to that month | [optional] 
 **end** | **str**| End of date range YYYY-MM-DD | [optional] 
 **filter** | [**object**](.md)| Filter results on any key value pair. &lt;br&gt;ex: &lt;code&gt;{\&quot;method\&quot;:\&quot;charge\&quot;}&lt;/code&gt; or nested &lt;code&gt;{\&quot;message\&quot;:{\&quot;details\&quot;: { \&quot;Batch\&quot;: {\&quot;HostItemID\&quot;: \&quot;12\&quot;}}}}&lt;/code&gt; | [optional] 
 **timezone** | **str**| Convert to timezone. &lt;code&gt;default&lt;/code&gt;: tz set in client preferences | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **settle**
> list[Response] settle(id, ticket=ticket, meta=meta)

Same as sending a transactionId to charge, this method will settle an outstanding Authorization.

Same as sending a transactionId to charge, this method will settle an outstanding Authorization.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
id = 'id_example' # str | Transaction ID of charged event
ticket = 'ticket_example' # str | Ticket Number used by POS (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # Same as sending a transactionId to charge, this method will settle an outstanding Authorization.
    api_response = api_instance.settle(id, ticket=ticket, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->settle: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Transaction ID of charged event | 
 **ticket** | **str**| Ticket Number used by POS | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **subscription**
> list[Response] subscription(amount, start, interval, email, payment, id=id, cancel_id=cancel_id, end=end, cycles=cycles, frequency=frequency)

Setup a payment subscription or get details/history. Can also send to /api/charge

Setup a payment subscription or get details/history. Can also send to /api/charge

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
amount = 'amount_example' # str | Amount charged per cycle.
start = 'start_example' # str | Start of subscription <code>YYYY-MM-DD</code>
interval = 'interval_example' # str | <code>daily, weekly, monthly, yearly</code>
email = 'email_example' # str | Subscribers email address
payment = NULL # object | Same details as <code>charge</code>. (credit card only method supported currently)
id = 'id_example' # str | GET specific subscription by id.  AN empty call gets a list of all current subscriptions (optional)
cancel_id = 'cancel_id_example' # str | Subscription ID you want to cancel (optional)
end = 'end_example' # str | End of subscription. <code>YYYY-MM-DD</code> Empty means forever. (optional)
cycles = 'cycles_example' # str | Set number of iterations. <code>end</code> will be calculated for you.  (optional)
frequency = 1.2 # float | 1 means every interval, 2 would mean every other interval <code>*</code> Every other week would be 2 (optional)

try:
    # Setup a payment subscription or get details/history. Can also send to /api/charge
    api_response = api_instance.subscription(amount, start, interval, email, payment, id=id, cancel_id=cancel_id, end=end, cycles=cycles, frequency=frequency)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->subscription: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **str**| Amount charged per cycle. | 
 **start** | **str**| Start of subscription &lt;code&gt;YYYY-MM-DD&lt;/code&gt; | 
 **interval** | **str**| &lt;code&gt;daily, weekly, monthly, yearly&lt;/code&gt; | 
 **email** | **str**| Subscribers email address | 
 **payment** | [**object**](.md)| Same details as &lt;code&gt;charge&lt;/code&gt;. (credit card only method supported currently) | 
 **id** | **str**| GET specific subscription by id.  AN empty call gets a list of all current subscriptions | [optional] 
 **cancel_id** | **str**| Subscription ID you want to cancel | [optional] 
 **end** | **str**| End of subscription. &lt;code&gt;YYYY-MM-DD&lt;/code&gt; Empty means forever. | [optional] 
 **cycles** | **str**| Set number of iterations. &lt;code&gt;end&lt;/code&gt; will be calculated for you.  | [optional] 
 **frequency** | **float**| 1 means every interval, 2 would mean every other interval &lt;code&gt;*&lt;/code&gt; Every other week would be 2 | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **terminal**
> list[Response] terminal(terminal_id, activation_code=activation_code, meta=meta)

Configure new Credit Card Terminal or get status of existing.

Configure new Credit Card Terminal or get status of existing.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
terminal_id = 'terminal_id_example' # str | Name of Terminal
activation_code = 'activation_code_example' # str | Activation Code on Terminal Screen (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # Configure new Credit Card Terminal or get status of existing.
    api_response = api_instance.terminal(terminal_id, activation_code=activation_code, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->terminal: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **terminal_id** | **str**| Name of Terminal | 
 **activation_code** | **str**| Activation Code on Terminal Screen | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tokenize**
> list[Response] tokenize(cc, mm, yy, cvv, account_number, routing_number)

Create a token for later use.

Create a token for later use.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
cc = 'cc_example' # str | Credit Card Number with or without dashes
mm = 'mm_example' # str | 2 digit Month
yy = 'yy_example' # str | 2 digit Year
cvv = 'cvv_example' # str | Card Verification Value found on the card (CVV2, CVC2, CID)
account_number = 'account_number_example' # str | Bank Account Number
routing_number = 'routing_number_example' # str | Bank Routing Number

try:
    # Create a token for later use.
    api_response = api_instance.tokenize(cc, mm, yy, cvv, account_number, routing_number)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->tokenize: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cc** | **str**| Credit Card Number with or without dashes | 
 **mm** | **str**| 2 digit Month | 
 **yy** | **str**| 2 digit Year | 
 **cvv** | **str**| Card Verification Value found on the card (CVV2, CVC2, CID) | 
 **account_number** | **str**| Bank Account Number | 
 **routing_number** | **str**| Bank Routing Number | 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **void**
> list[Response] void(id, ticket=ticket, meta=meta)

A Void transaction can be used to back out a previous Sale transaction.

A Void transaction can be used to back out a previous Sale transaction.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ApiApi()
id = 'id_example' # str | Transaction ID of charged event
ticket = 'ticket_example' # str | Ticket Number used by POS (optional)
meta = NULL # object | Optional user defined object to be returned with future response (optional)

try:
    # A Void transaction can be used to back out a previous Sale transaction.
    api_response = api_instance.void(id, ticket=ticket, meta=meta)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ApiApi->void: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Transaction ID of charged event | 
 **ticket** | **str**| Ticket Number used by POS | [optional] 
 **meta** | [**object**](.md)| Optional user defined object to be returned with future response | [optional] 

### Return type

[**list[Response]**](Response.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

