<?php

if (!function_exists('curl_init')) {
  throw new Exception('Triple needs the CURL PHP extension.');
}
if (!function_exists('json_decode')) {
  throw new Exception('Triple needs the JSON PHP extension.');
}
if (!function_exists('mb_detect_encoding')) {
  throw new Exception('Triple needs the Multibyte String PHP extension.');
}

require(dirname(__FILE__) . '/Triple/Triple.php');

require(dirname(__FILE__) . '/Triple/Util.php');
require(dirname(__FILE__) . '/Triple/Util/Set.php');

require(dirname(__FILE__) . '/Triple/Error.php');
require(dirname(__FILE__) . '/Triple/ApiError.php');
require(dirname(__FILE__) . '/Triple/ApiConnectionError.php');
require(dirname(__FILE__) . '/Triple/AuthenticationError.php');
require(dirname(__FILE__) . '/Triple/CardError.php');
require(dirname(__FILE__) . '/Triple/InvalidRequestError.php');
require(dirname(__FILE__) . '/Triple/RateLimitError.php');

require(dirname(__FILE__) . '/Triple/Object.php');
require(dirname(__FILE__) . '/Triple/ApiRequestor.php');
require(dirname(__FILE__) . '/Triple/ApiResource.php');
require(dirname(__FILE__) . '/Triple/SingletonApiResource.php');
require(dirname(__FILE__) . '/Triple/AttachedObject.php');
require(dirname(__FILE__) . '/Triple/List.php');
require(dirname(__FILE__) . '/Triple/RequestOptions.php');

// Triple API Resources
require(dirname(__FILE__) . '/Triple/Account.php');
require(dirname(__FILE__) . '/Triple/Card.php');
require(dirname(__FILE__) . '/Triple/Balance.php');
require(dirname(__FILE__) . '/Triple/BalanceTransaction.php');
require(dirname(__FILE__) . '/Triple/Charge.php');
require(dirname(__FILE__) . '/Triple/Customer.php');
require(dirname(__FILE__) . '/Triple/FileUpload.php');
require(dirname(__FILE__) . '/Triple/Invoice.php');
require(dirname(__FILE__) . '/Triple/InvoiceItem.php');
require(dirname(__FILE__) . '/Triple/Plan.php');
require(dirname(__FILE__) . '/Triple/Subscription.php');
require(dirname(__FILE__) . '/Triple/Token.php');
require(dirname(__FILE__) . '/Triple/Coupon.php');
require(dirname(__FILE__) . '/Triple/Event.php');
require(dirname(__FILE__) . '/Triple/Transfer.php');
require(dirname(__FILE__) . '/Triple/Recipient.php');
require(dirname(__FILE__) . '/Triple/Refund.php');
require(dirname(__FILE__) . '/Triple/ApplicationFee.php');
require(dirname(__FILE__) . '/Triple/ApplicationFeeRefund.php');
require(dirname(__FILE__) . '/Triple/BitcoinReceiver.php');
require(dirname(__FILE__) . '/Triple/BitcoinTransaction.php');
