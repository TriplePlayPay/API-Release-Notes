<?php

class TriplePlayPay_Account extends TriplePlayPay_SingletonApiResource
{
  /**
    * @param string|null $apiKey
    *
    * @return TriplePlayPay_Account
    */
  public static function retrieve($apiKey=null)
  {
    $class = get_class();
    return self::_scopedSingletonRetrieve($class, $apiKey);
  }
}
