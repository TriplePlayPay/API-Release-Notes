<?php

class TriplePlayPay_ApiConnectionError extends TriplePlayPay_Error
{
}
