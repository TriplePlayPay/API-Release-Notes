<?php

class TriplePlayPay_ApiError extends TriplePlayPay_Error
{
}
