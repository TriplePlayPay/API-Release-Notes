<?php

class TriplePlayPay_ApplicationFeeRefund extends TriplePlayPay_ApiResource
{
  /**
   * @return string The API URL for this TriplePlayPay refund.
   */
  public function instanceUrl()
  {
    $id = $this['id'];
    $fee = $this['fee'];
    if (!$id) {
      throw new TriplePlayPay_InvalidRequestError(
          "Could not determine which URL to request: " .
          "class instance has invalid ID: $id",
          null
      );
    }
    $id = TriplePlayPay_ApiRequestor::utf8($id);
    $fee = TriplePlayPay_ApiRequestor::utf8($fee);

    $base = self::classUrl('TriplePlayPay_ApplicationFee');
    $feeExtn = urlencode($fee);
    $extn = urlencode($id);
    return "$base/$feeExtn/refunds/$extn";
  }

  /**
   * @return TriplePlayPay_ApplicationFeeRefund The saved refund.
   */
  public function save()
  {
    $class = get_class();
    return self::_scopedSave($class);
  }
}
