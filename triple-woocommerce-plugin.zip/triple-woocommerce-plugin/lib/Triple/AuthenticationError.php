<?php

class TriplePlayPay_AuthenticationError extends TriplePlayPay_Error
{
}
