<?php

class TriplePlayPay_Balance extends TriplePlayPay_SingletonApiResource
{
  /**
    * @param string|null $apiKey
    *
    * @return TriplePlayPay_Balance
    */
  public static function retrieve($apiKey=null)
  {
    $class = get_class();
    return self::_scopedSingletonRetrieve($class, $apiKey);
  }
}
