<?php

class TriplePlayPay_BitcoinTransaction extends TriplePlayPay_ApiResource
{

}

