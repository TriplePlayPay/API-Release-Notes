<?php

class TriplePlayPay_Customer extends TriplePlayPay_ApiResource
{
  /**
   * @param string $id The ID of the customer to retrieve.
   * @param string|null $apiKey
   *
   * @return TriplePlayPay_Customer
   */
  public static function retrieve($id, $apiKey=null)
  {
    $class = get_class();
    return self::_scopedRetrieve($class, $id, $apiKey);
  }

  /**
   * @param array|null $params
   * @param string|null $apiKey
   *
   * @return array An array of TriplePlayPay_Customers.
   */
  public static function all($params=null, $apiKey=null)
  {
    $class = get_class();
    return self::_scopedAll($class, $params, $apiKey);
  }

  /**
   * @param array|null $params
   * @param string|null $apiKey
   *
   * @return TriplePlayPay_Customer The created customer.
   */
  public static function create($params=null, $apiKey=null)
  {
    $class = get_class();
    return self::_scopedCreate($class, $params, $apiKey);
  }

  /**
   * @returns TriplePlayPay_Customer The saved customer.
   */
  public function save()
  {
    $class = get_class();
    return self::_scopedSave($class);
  }

  /**
   * @param array|null $params
   *
   * @returns TriplePlayPay_Customer The deleted customer.
   */
  public function delete($params=null)
  {
    $class = get_class();
    return self::_scopedDelete($class, $params);
  }

  /**
   * @param array|null $params
   *
   * @returns TriplePlayPay_InvoiceItem The resulting invoice item.
   */
  public function addInvoiceItem($params=null)
  {
    if (!$params)
      $params = array();
    $params['customer'] = $this->id;
    $ii = TriplePlayPay_InvoiceItem::create($params, $this->_apiKey);
    return $ii;
  }

  /**
   * @param array|null $params
   *
   * @returns array An array of the customer's TriplePlayPay_Invoices.
   */
  public function invoices($params=null)
  {
    if (!$params)
      $params = array();
    $params['customer'] = $this->id;
    $invoices = TriplePlayPay_Invoice::all($params, $this->_apiKey);
    return $invoices;
  }

  /**
   * @param array|null $params
   *
   * @returns array An array of the customer's TriplePlayPay_InvoiceItems.
   */
  public function invoiceItems($params=null)
  {
    if (!$params)
      $params = array();
    $params['customer'] = $this->id;
    $iis = TriplePlayPay_InvoiceItem::all($params, $this->_apiKey);
    return $iis;
  }

  /**
   * @param array|null $params
   *
   * @returns array An array of the customer's TriplePlayPay_Charges.
   */
  public function charges($params=null)
  {
    if (!$params)
      $params = array();
    $params['customer'] = $this->id;
    $charges = TriplePlayPay_Charge::all($params, $this->_apiKey);
    return $charges;
  }

  /**
   * @param array|null $params
   *
   * @returns TriplePlayPay_Subscription The updated subscription.
   */
  public function updateSubscription($params=null)
  {
    $requestor = new TriplePlayPay_ApiRequestor($this->_apiKey);
    $url = $this->instanceUrl() . '/subscription';
    list($response, $apiKey) = $requestor->request('post', $url, $params);
    $this->refreshFrom(array('subscription' => $response), $apiKey, true);
    return $this->subscription;
  }

  /**
   * @param array|null $params
   *
   * @returns TriplePlayPay_Subscription The cancelled subscription.
   */
  public function cancelSubscription($params=null)
  {
    $requestor = new TriplePlayPay_ApiRequestor($this->_apiKey);
    $url = $this->instanceUrl() . '/subscription';
    list($response, $apiKey) = $requestor->request('delete', $url, $params);
    $this->refreshFrom(array('subscription' => $response), $apiKey, true);
    return $this->subscription;
  }

  /**
   * @param array|null $params
   *
   * @returns TriplePlayPay_Customer The updated customer.
   */
  public function deleteDiscount()
  {
    $requestor = new TriplePlayPay_ApiRequestor($this->_apiKey);
    $url = $this->instanceUrl() . '/discount';
    list($response, $apiKey) = $requestor->request('delete', $url);
    $this->refreshFrom(array('discount' => null), $apiKey, true);
  }
}
