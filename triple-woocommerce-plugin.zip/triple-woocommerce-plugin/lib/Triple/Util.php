<?php

abstract class TriplePlayPay_Util
{
  /**
   * Whether the provided array (or other) is a list rather than a dictionary.
   *
   * @param array|mixed $array
   * @return boolean True if the given object is a list.
   */
  public static function isList($array)
  {
    if (!is_array($array))
      return false;

    // TODO: generally incorrect, but it's correct given TriplePlayPay's response
    foreach (array_keys($array) as $k) {
      if (!is_numeric($k))
        return false;
    }
    return true;
  }

  /**
   * Recursively converts the PHP TriplePlayPay object to an array.
   *
   * @param array $values The PHP TriplePlayPay object to convert.
   * @return array
   */
  public static function convertTriplePlayPayObjectToArray($values)
  {
    $results = array();
    foreach ($values as $k => $v) {
      // FIXME: this is an encapsulation violation
      if ($k[0] == '_') {
        continue;
      }
      if ($v instanceof TriplePlayPay_Object) {
        $results[$k] = $v->__toArray(true);
      } else if (is_array($v)) {
        $results[$k] = self::convertTriplePlayPayObjectToArray($v);
      } else {
        $results[$k] = $v;
      }
    }
    return $results;
  }

  /**
   * Converts a response from the TriplePlayPay API to the corresponding PHP object.
   *
   * @param array $resp The response from the TriplePlayPay API.
   * @param string $apiKey
   * @return TriplePlayPay_Object|array
   */
  public static function convertToTriplePlayPayObject($resp, $apiKey)
  {
    $types = array(
      'card' => 'TriplePlayPay_Card',
      'charge' => 'TriplePlayPay_Charge',
      'coupon' => 'TriplePlayPay_Coupon',
      'customer' => 'TriplePlayPay_Customer',
      'list' => 'TriplePlayPay_List',
      'invoice' => 'TriplePlayPay_Invoice',
      'invoiceitem' => 'TriplePlayPay_InvoiceItem',
      'event' => 'TriplePlayPay_Event',
      'transfer' => 'TriplePlayPay_Transfer',
      'plan' => 'TriplePlayPay_Plan',
      'recipient' => 'TriplePlayPay_Recipient',
      'refund' => 'TriplePlayPay_Refund',
      'subscription' => 'TriplePlayPay_Subscription',
      'fee_refund' => 'TriplePlayPay_ApplicationFeeRefund',
      'bitcoin_receiver' => 'TriplePlayPay_BitcoinReceiver',
      'bitcoin_transaction' => 'TriplePlayPay_BitcoinTransaction'
    );
    if (self::isList($resp)) {
      $mapped = array();
      foreach ($resp as $i)
        array_push($mapped, self::convertToTriplePlayPayObject($i, $apiKey));
      return $mapped;
    } else if (is_array($resp)) {
      if (isset($resp['object'])
          && is_string($resp['object'])
          && isset($types[$resp['object']])) {
        $class = $types[$resp['object']];
      } else {
        $class = 'TriplePlayPay_Object';
      }
      return TriplePlayPay_Object::scopedConstructFrom($class, $resp, $apiKey);
    } else {
      return $resp;
    }
  }
}
