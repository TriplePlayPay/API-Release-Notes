==== TriplePlayPay Payment Gateway WooCommerce Addon ====
Contributors: nazrulhassanmca
Plugin Name: TriplePlayPay WooCommerce Addon
Tags: woocommerce, triple, woocommerce addon triple, triple for woocommerce,triple for wordpress,triple payment method,triple payment in wordpress,triple payment gateway for woocommerce,wordpress triple wocommmerce,woocommerce triple gateway download,triple plugin for woocommerce,triple woocommerce plugin,triple payment gateway for wordpress,triple payment gateway for woocommerce,woocommerce triple payment gateway,woocommerce credit cards payment with triple
Author: TriplePlayPay
Requires at least: 4.0  & WooCommerce 2.2+
Tested up to: 4.3 & WooCommerce 2.4.6
Stable tag: 1.5.0
Version: 1.5.0
License: http://www.gnu.org/licenses/gpl-2.0.html
